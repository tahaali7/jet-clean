#!/bin/bash
# ============================================
# سكريبت الرجوع من PostgreSQL إلى SQLite
# ============================================

set -e

cd /home/z/my-project

echo "🔄 الرجوع إلى SQLite..."

# 1. تحديث .env
cat > .env << 'EOF'
DATABASE_URL=file:/home/z/my-project/db/custom.db
EOF

# 2. نسخ schema لـ SQLite
cat > prisma/schema.prisma << 'EOF'
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

model Branch {
  id            String         @id @default(cuid())
  name          String         @unique
  employees     Employee[]
  carEntries    CarEntry[]
  workerExpenses WorkerExpense[]
  treasuries    Treasury[]
  records       Record[]
  closedDays    ClosedDay[]
}

model Employee {
  id       String  @id @default(cuid())
  name     String
  branchId String
  branch   Branch  @relation(fields: [branchId], references: [id])
  shift    String
  password String
  records  Record[]
}

model AdminAccount {
  id       String @id @default("admin")
  name     String @default("طه علي")
  password String @default("19970880528")
}

model CarEntry {
  id           String   @id @default(cuid())
  date         String
  branchId     String
  branch       Branch   @relation(fields: [branchId], references: [id])
  empId        String
  empName      String
  room         String
  totalCars    Int      @default(0)
  totalAmount  Int      @default(0)
  extraCars    Int      @default(0)
  extraAmount  Int      @default(0)
  priceCounts  String   @default("{}")
  customPrices String   @default("{}")
  createdAt    DateTime @default(now())
}

model WorkerExpense {
  id       String @id @default(cuid())
  date     String
  branchId String
  branch   Branch @relation(fields: [branchId], references: [id])
  amount   Int    @default(0)
  note     String @default("")
}

model Treasury {
  id       String @id @default(cuid())
  date     String
  branchId String
  branch   Branch @relation(fields: [branchId], references: [id])
  total    Int    @default(0)
  cash     Int    @default(0)
  later    Int    @default(0)
}

model Record {
  id       String   @id @default(cuid())
  empId    String
  type     String
  amount   Int
  note     String   @default("")
  date     String
  branchId String
  branch   Branch @relation(fields: [branchId], references: [id])
  employee Employee @relation(fields: [empId], references: [id])
}

model ClosedDay {
  id       String @id @default(cuid())
  date     String
  branchId String
  branch   Branch @relation(fields: [branchId], references: [id])
}
EOF

# 3. توليد Prisma Client
echo "⚙️ توليد Prisma Client..."
npx prisma generate

# 4. دفع الـ Schema
echo "🗄️ إنشاء الجداول..."
npx prisma db push --accept-data-loss

# 5. إعادة البناء
echo "🔨 إعادة بناء التطبيق..."
npx next build

echo ""
echo "✅ تم الرجوع إلى SQLite بنجاح!"
